import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                HStack(spacing: 10) {
                    Image(systemName: "sum")
                        .font(.largeTitle)
                    Image(systemName: "sum")
                        .font(.largeTitle)
                }
                NavigationLink(destination: GameView()) {
                    Text("Start the Game")
                        .font(.largeTitle)
                }
            }
            .navigationTitle("Home")
        }
    }
}

struct GameView: View {
    
    @State var timeRemaining = 30
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var randNum1 = Int.random(in: 1..<51)
    @State var randNum2 = Int.random(in: 1..<51)
    @State var answer = ""
    @State var backgroundColour = Color(UIColor.systemBackground)
    @State var showAlert = false
    @State var gameFinish = false
    
    @State var correct = 0
    
    
    var body: some View {
        ZStack {
            backgroundColour //Used to set the background colour of the webpage. You can change it to green when they win
                .ignoresSafeArea()
            VStack(spacing: 20) {
                HStack {
                    //Create a label to display the remaning time 
                    //Create the score label
                }
                //Show the question
                //Create a text field for the answer
                Button("Enter") {
                    //Check if the textfield answer is the same as the randomly generated number
                    //Generate new numbers, reset textfield, increment correct count
                }.buttonStyle(.borderedProminent)
                    .disabled(gameFinish)
            }   
        }.alert(isPresented: $showAlert) { 
            Alert(title: Text("Time's Up!"),
                  message: Text("The timer has finished."),
                  dismissButton: .default(Text("OK")))
            
        }.navigationTitle("Game")
    }
}


