import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                HStack(spacing: 10) {
                    Image(systemName: "sum")
                        .font(.largeTitle)
                    Image(systemName: "sum")
                        .font(.largeTitle)
                }
                NavigationLink(destination: GameView()) {
                    Text("Start the Game")
                        .font(.largeTitle)
                }
            }
            .navigationTitle("Home")
        }
    }
}

struct GameView: View {
    
    @State var timeRemaining = 30
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var randNum1 = Int.random(in: 1..<51)
    @State var randNum2 = Int.random(in: 1..<51)
    @State var answer = ""
    @State var backgroundColour = Color(UIColor.systemBackground)
    @State var showAlert = false
    @State var gameFinish = false
    
    @State var correct = 0
    
    
    var body: some View {
        ZStack {
            backgroundColour
                .ignoresSafeArea()
            VStack(spacing: 20) {
                HStack {
                    Text("Time: \(timeRemaining)")
                        .onReceive(timer) { _ in
                            if (timeRemaining == 0 && !gameFinish) {
                                if correct >= 5 {
                                    backgroundColour = Color.green
                                }
                                showAlert = true
                                gameFinish = true
                            }
                            if timeRemaining > 0 {
                                timeRemaining -= 1
                            }
                        }
                        .font(.system(size: 20))
                        .padding()
                    Text("Score: \(correct)")
                        .font(.system(size: 20))
                }
                Text("\(randNum1)+\(randNum2)")
                .font(.system(size: 24))
                TextField("Answer", text: $answer)
                    .frame(width: 250, height: 40) // Set specific width and height
                    .background(Color.gray.opacity(0.2)) // Background color for TextField
                    .cornerRadius(8)
                    .multilineTextAlignment(.center)
                    .padding()
                Button("Enter") {
                    if Int(answer) == randNum1+randNum2 {
                        correct += 1
                        randNum1 = Int.random(in: 1..<51)
                        randNum2 = Int.random(in: 1..<51)
                        answer = ""
                    }
                }.buttonStyle(.borderedProminent)
                    .disabled(gameFinish)
            }   
        }.alert(isPresented: $showAlert) { 
            Alert(title: Text("Time's Up!"),
                  message: Text("The timer has finished."),
                  dismissButton: .default(Text("OK")))
            
        }.navigationTitle("Game")
    }
}


